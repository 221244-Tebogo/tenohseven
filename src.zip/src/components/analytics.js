import React from 'react'

const analytics = () => {
  return (
    <div>
      Analytics
    </div>
  )
}

export default analytics
