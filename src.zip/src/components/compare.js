import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Tagsinput from '../components/tagsinput';
import DailyQuote from './DailyQuote';
import { Text, View } from 'react-native';
import { Calendar } from 'react-native-calendars';
//import Table from './table';

function Compare(){
    return (
        <div>
        <Container>
        <Row>
        <Col>
        <h4>Featured Tags</h4>
        <Tagsinput />
        </Col>

{/*Calendar inserted here*/}
        <Col>Customer Meeting Calendar <br>
        <Calendar />
        </Col>
        </Row>
    <Row>

{/*table uses 3 columns at the bottom, column 1 its */}
        <Col>
        <h4>Featured Tags</h4>
        <Tagsinput />

{/*I've inserted daily quotes here using a simple table*/}
        </Col>
        <div className="DailyQuote-container">
        <DailyQuote />
        </div>
        <Col>

    
        </Col>
        <Col>
        <h4>Valuable Customers</h4>
        3 of 3</Col>
        </Row>
    </Container>
    
        </div>
    
    )
    }

    export default Compare;