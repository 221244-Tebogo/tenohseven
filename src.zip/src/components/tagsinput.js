import React from 'react'
import '../cards.css'

const tagsinput = () => {
return (
    <div className="tags-input-container">
        <div className="tags-item">
            <span className="text">web</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">website</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">logo design</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">graphic design</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">web</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">website</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">logo design</span>
            <span className="close">&times;</span>
        </div>
        <div className="tags-item">
            <span className="text">graphic design</span>
            <span className="close">&times;</span>
        </div>
        </div>
)
}

export default tagsinput
