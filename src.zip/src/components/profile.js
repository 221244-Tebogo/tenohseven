import React from 'react'

const profile = () => {
  return (
    <div>
      PROFILE
    </div>
  )
}

export default profile
