import React from 'react'
import Card from 'react-bootstrap/Card'

const cards = () => {
    return (
    <div className='container'>
    <section>
        <h1>CARD IS HERE</h1>
        
    </section>
    </div>
)
}

export default cards
