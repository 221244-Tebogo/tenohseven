import React from 'react'

const dashboard = () => {
  return (
    <div>
      Dashboard
    </div>
  )
}

export default dashboard
