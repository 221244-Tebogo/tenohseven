import React from "react";
//import fb from '../assets/facebook.png'
//import twitter from '../assets/twitter.png'
//import instagram from '../imgs/instagram.png'
//import logo from '../assets/logo.png'

const Footer=()=>{
    return(
        <div className="footer">
            <p>
                @{new Date().getFullYear} tenOhseven. All rights reserved.
            </p>

        </div>
    )
}
export default Footer;