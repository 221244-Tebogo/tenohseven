//import logo from './logo.svg';
import React from 'react';
//import './App.css';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Cards from './components/cards';
import Compare from './components/compare';
//import { Route, Routes } from 'react-router-dom';
import BasicNavbar from './components/navbar';

function App() {
  return (
    <div className="App">
      <BasicNavbar />
      <Compare />
      <Cards />
    </div>
  );
}

export default App;